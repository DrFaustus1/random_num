# Номер успешной посылки: 144375503
def main():
    robot_weight: list[int] = [int(x) for x in input().split()]
    limit: int = int(input())
    platform_counter: int = 0
    i: int = 0
    j: int = len(robot_weight) -1
    robot_weight.sort()
    while i <= j:
        if robot_weight[i] + robot_weight[j] <= limit:
            i += 1
        j -= 1
        platform_counter += 1
    print(platform_counter)
main()