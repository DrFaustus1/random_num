#номер посылки: 146379540
def read_data():
    data = input()
    return data

def marsohod(data: str, data_index: int) -> tuple:
    result: str = ''
    current_number: int = 0
    while data_index < len(data):
        symbol = data[data_index]

        if symbol.isdigit():
            current_number = current_number * 10 + int(symbol)
            data_index+=1
        elif symbol == '[':
            substring, new_index = marsohod(data, data_index+1)
            result += substring * current_number
            current_number = 0
            data_index = new_index
        elif symbol == ']':
            return (result, data_index+1)
        else: 
            result += symbol 
            data_index += 1
    return (result, data_index)

def main():
    symbols = read_data()
    initial_index = 0
    print(marsohod(symbols, initial_index)[0])

main()